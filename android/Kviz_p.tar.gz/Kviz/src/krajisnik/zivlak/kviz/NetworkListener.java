package krajisnik.zivlak.kviz;


public class NetworkListener implements Runnable
{
    // Activity variables
    private MainActivity mainActivity;
    
    // Global variables
    private String data = "";
    private Boolean run = true;
    
    // Constructor
    public NetworkListener(MainActivity a)
    {
        mainActivity = a;
    }
    
    // Main function of NetworkListener
    @Override
    public void run()
    {
        while(run)
        {
            data = Network.readString();
            mainActivity.lblIp.post(new Runnable()
            {
                @Override
                public void run()
                {
                    mainActivity.lblIp.setText(data);
                }
            });
            
            // Recive code for quit
            if(data.equalsIgnoreCase("quit"))
                run = false;
        }
  }
}
