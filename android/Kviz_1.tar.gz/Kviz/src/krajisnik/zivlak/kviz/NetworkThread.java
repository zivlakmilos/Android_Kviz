package krajisnik.zivlak.kviz;


public class NetworkThread implements Runnable
{
    private MainActivity mainActivity;
    // Private global variables
    private String data = "";
    private Boolean run = true;
    
    // Constructor
//    public NetworkThread(MainActivity a)
//    {
//        mainActivity = a;
//    }
    
    // Constructor
    public NetworkThread(MainActivity a)
    {
        mainActivity = a;
    }
    
    // Main function of NetworkThread
    @Override
    public void run()
    {
        while(run)
        {
            data = Network.readString();
            mainActivity.test(data);
            
            // Recive code for quit
            if(data.equalsIgnoreCase("quit"))
                run = false;
        }
  }
}
