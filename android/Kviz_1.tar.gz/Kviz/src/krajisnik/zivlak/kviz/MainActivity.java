package krajisnik.zivlak.kviz;

import android.app.Activity;
import android.os.Bundle;
import android.widget.*;
import android.view.*;
import android.view.View.*;


public class MainActivity extends Activity
{
    // Visual components
    private TextView ipLabel;
    private EditText ip;
    private TextView mainLabel;
    private EditText name;
    private Button register;
    private Button exit;
    
    // Global private variables
    private Thread networkThread;
    
    //private MainActivity mainActivity = this;
    
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        ipLabel = (TextView) this.findViewById(R.id.ipLabel);
        ip = (EditText) this.findViewById(R.id.ip);
        mainLabel = (TextView) this.findViewById(R.id.manLabel);
        name = (EditText) this.findViewById(R.id.name);
        register = (Button) this.findViewById(R.id.register);
        exit = (Button) this.findViewById(R.id.exit);
        
        networkThread = new Thread(new NetworkThread(this));
        
        register.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                Network.open(ip.getText().toString());
                Network.sendString(name.getText().toString());
                
                //networkThread = new Thread(new NetworkThread());
                networkThread.start();
                
                //new Thread(new NetworkThread(mainActivity)).start();
                
                //ipLabel.setVisibility(View.INVISIBLE);
                ip.setVisibility(View.INVISIBLE);
                mainLabel.setVisibility(View.INVISIBLE);
                name.setVisibility(View.INVISIBLE);
                register.setVisibility(View.INVISIBLE);
                
                mainLabel.setText(Network.readString());
                
//                Socket client = null;
//                DataOutputStream os = null;
//                try
//                {
//                    client = new Socket("192.168.0.12", 4444);
//                    os = new DataOutputStream(client.getOutputStream());
//                    os.writeUTF("TEST");
//                } catch(IOException ioe)
//                {
//                    mainLabel.setText(ioe.toString());
//                }
            }
        });
        
        exit.setOnClickListener(new OnClickListener()
        {
            @Override
            public void onClick(View view)
            {
                networkThread.stop();
                Network.close();
                System.exit(0);
            }
        });
    }
    
    public void test(String data)
    {
        ipLabel.setVisibility(View.VISIBLE);
        ipLabel.setText(data);
    }
}
